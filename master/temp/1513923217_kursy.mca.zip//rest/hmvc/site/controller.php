<?php 
class SiteController extends BaseController
{

		public function ActionIndex()
		{
							$this->out_view('index',array());
						}
		
	
}
?>