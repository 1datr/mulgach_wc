<?php
namespace Kursy\Backend;

class ModelUrok extends \AuthModel
{
	
}