<?php
namespace Kursy\Backend;

class ModelStudent extends \AuthModel
{
	
}