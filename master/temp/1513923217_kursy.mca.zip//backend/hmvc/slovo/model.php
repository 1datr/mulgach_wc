<?php
namespace Kursy\Backend;

class ModelSlovo extends \AuthModel
{
	
}