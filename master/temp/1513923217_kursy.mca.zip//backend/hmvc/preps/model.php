<?php
namespace Kursy\Backend;

class ModelPreps extends \AuthModel
{
	
}