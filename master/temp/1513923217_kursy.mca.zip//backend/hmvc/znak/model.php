<?php
namespace Kursy\Backend;

class ModelZnak extends \AuthModel
{
	
}