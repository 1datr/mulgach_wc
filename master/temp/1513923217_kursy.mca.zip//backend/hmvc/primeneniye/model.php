<?php
namespace Kursy\Backend;

class ModelPrimeneniye extends \AuthModel
{
	
}