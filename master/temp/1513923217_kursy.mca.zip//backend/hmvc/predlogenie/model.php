<?php
namespace Kursy\Backend;

class ModelPredlogenie extends \AuthModel
{
	
}