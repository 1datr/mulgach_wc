<?php
namespace Kursy\Backend;

class ModelRazdel extends \AuthModel
{
	
}