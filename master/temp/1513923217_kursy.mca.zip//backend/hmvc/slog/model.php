<?php
namespace Kursy\Backend;

class ModelSlog extends \AuthModel
{
	
}