<?php
namespace Kursy\Backend;

class ModelLifearea extends \AuthModel
{
	
}