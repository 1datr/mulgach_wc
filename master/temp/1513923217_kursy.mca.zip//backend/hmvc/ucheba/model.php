<?php
namespace Kursy\Backend;

class ModelUcheba extends \AuthModel
{
	
}