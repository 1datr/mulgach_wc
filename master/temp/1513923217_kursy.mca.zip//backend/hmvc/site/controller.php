<?php 
namespace Kursy\Backend;

class SiteController extends \BaseController
{

		public function ActionIndex()
		{
							$this->redirect('users');
						}
		
	
}
?>