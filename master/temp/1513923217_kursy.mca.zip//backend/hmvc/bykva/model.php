<?php
namespace Kursy\Backend;

class ModelBykva extends \AuthModel
{
	
}