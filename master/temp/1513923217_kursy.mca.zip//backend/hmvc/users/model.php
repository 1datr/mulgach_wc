<?php
namespace Kursy\Backend;

class ModelUsers extends \AuthModel
{
	
}