<?php
namespace Kursy\Backend;

class ModelKursy extends \AuthModel
{
	
}