<?php
namespace Kursy\Backend;

class ModelZadanie extends \AuthModel
{
	
}