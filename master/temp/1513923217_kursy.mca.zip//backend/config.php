<?php
$conf = array(
	"sess_user_descriptor"=>"admin",
);
?>