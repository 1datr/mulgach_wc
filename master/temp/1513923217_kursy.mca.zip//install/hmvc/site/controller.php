<?php 
class SiteController extends InstallController
{
			
	
}
?>