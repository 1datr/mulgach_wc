<?php
namespace Kursy\Install;

class ModelPredlogenie extends \AuthModel
{
	
}