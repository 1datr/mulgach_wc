<?php
namespace Kursy\Install;

class ModelPreps extends \AuthModel
{
	
}