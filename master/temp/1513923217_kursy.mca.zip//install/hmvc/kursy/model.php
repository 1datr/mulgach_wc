<?php
namespace Kursy\Install;

class ModelKursy extends \AuthModel
{
	
}