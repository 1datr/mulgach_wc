<?php
namespace Kursy\Install;

class ModelSlovo extends \AuthModel
{
	
}