<?php
namespace Kursy\Install;

class ModelZadanie extends \AuthModel
{
	
}