<?php
namespace Kursy\Install;

class ModelPrimeneniye extends \AuthModel
{
	
}