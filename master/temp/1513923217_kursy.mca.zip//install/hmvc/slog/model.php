<?php
namespace Kursy\Install;

class ModelSlog extends \AuthModel
{
	
}