<?php
namespace Kursy\Install;

class ModelUsers extends \AuthModel
{
	
}