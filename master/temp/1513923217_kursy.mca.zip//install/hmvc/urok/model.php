<?php
namespace Kursy\Install;

class ModelUrok extends \AuthModel
{
	
}