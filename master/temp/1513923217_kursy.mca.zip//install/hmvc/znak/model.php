<?php
namespace Kursy\Install;

class ModelZnak extends \AuthModel
{
	
}