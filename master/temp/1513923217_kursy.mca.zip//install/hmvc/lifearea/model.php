<?php
namespace Kursy\Install;

class ModelLifearea extends \AuthModel
{
	
}