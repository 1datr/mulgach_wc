<?php
namespace Kursy\Install;

class ModelRazdel extends \AuthModel
{
	
}