<?php
namespace Kursy\Install;

class ModelBykva extends \AuthModel
{
	
}