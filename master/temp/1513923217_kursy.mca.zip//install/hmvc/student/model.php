<?php
namespace Kursy\Install;

class ModelStudent extends \AuthModel
{
	
}