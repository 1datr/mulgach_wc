<?php
namespace Kursy\Install;

class ModelUcheba extends \AuthModel
{
	
}