<?php
namespace Kursy\Frontend;

class ModelUsers extends \AuthModel
{
	
}