<?php
namespace Kursy\Frontend;

class ModelPreps extends \AuthModel
{
	
}