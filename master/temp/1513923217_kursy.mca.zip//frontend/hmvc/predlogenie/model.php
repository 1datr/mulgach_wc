<?php
namespace Kursy\Frontend;

class ModelPredlogenie extends \AuthModel
{
	
}