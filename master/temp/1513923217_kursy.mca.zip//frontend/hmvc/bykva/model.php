<?php
namespace Kursy\Frontend;

class ModelBykva extends \AuthModel
{
	
}