<?php
namespace Kursy\Frontend;

class ModelRazdel extends \AuthModel
{
	
}