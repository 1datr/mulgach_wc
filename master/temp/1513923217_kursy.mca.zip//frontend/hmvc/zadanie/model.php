<?php
namespace Kursy\Frontend;

class ModelZadanie extends \AuthModel
{
	
}