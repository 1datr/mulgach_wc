<?php
namespace Kursy\Frontend;

class ModelZnak extends \AuthModel
{
	
}