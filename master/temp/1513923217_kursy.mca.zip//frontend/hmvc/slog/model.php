<?php
namespace Kursy\Frontend;

class ModelSlog extends \AuthModel
{
	
}