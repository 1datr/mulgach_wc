<?php
namespace Kursy\Frontend;

class ModelPrimeneniye extends \AuthModel
{
	
}