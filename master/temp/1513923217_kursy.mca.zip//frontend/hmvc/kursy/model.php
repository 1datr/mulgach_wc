<?php
namespace Kursy\Frontend;

class ModelKursy extends \AuthModel
{
	
}