<?php
namespace Kursy\Frontend;

class ModelStudent extends \AuthModel
{
	
}