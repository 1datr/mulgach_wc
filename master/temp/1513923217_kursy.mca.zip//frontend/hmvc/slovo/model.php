<?php
namespace Kursy\Frontend;

class ModelSlovo extends \AuthModel
{
	
}