<?php
namespace Kursy\Frontend;

class ModelLifearea extends \AuthModel
{
	
}