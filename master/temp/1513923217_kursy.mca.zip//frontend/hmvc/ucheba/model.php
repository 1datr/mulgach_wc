<?php
namespace Kursy\Frontend;

class ModelUcheba extends \AuthModel
{
	
}