<?php
namespace Kursy\Frontend;

class ModelUrok extends \AuthModel
{
	
}